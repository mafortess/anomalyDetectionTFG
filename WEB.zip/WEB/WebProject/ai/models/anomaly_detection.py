# ai/models/anomaly_detection.py

from sklearn.ensemble import IsolationForest

def train_isolation_forest(data, n_estimators=100, max_samples='auto', contamination='auto', random_state=42):
    """
    Entrena un modelo de Isolation Forest para la detección de anomalías.

    :param data: Datos preprocesados para entrenar el modelo.
    :param n_estimators: Número de árboles en el bosque.
    :param max_samples: Número de muestras para entrenar cada árbol base.
    :param contamination: Proporción de outliers en el conjunto de datos.
    :param random_state: Semilla para la reproducibilidad de los resultados.
    :return: Modelo entrenado de Isolation Forest.
    """
    model = IsolationForest(n_estimators=n_estimators, max_samples=max_samples,
                            contamination=contamination, random_state=random_state)
    model.fit(data)
    return model
