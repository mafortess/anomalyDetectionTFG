# ai/utils/data_preprocessing.py

import pandas as pd
from sklearn.preprocessing import StandardScaler

def prepare_data(data):
    """
    Prepares data for anomaly detection.
    
    :param data: DataFrame containing the features.
    :return: Scaled and cleaned data as DataFrame.
    """
    # Limpieza básica de datos
     # Identificar columnas numéricas (suponiendo que todas menos la última son numéricas)
    numeric_columns = data.columns[:-1]  # Excluye la última columna si es categórica
    data_cleaned = data[numeric_columns].dropna()  # Eliminar filas con valores nulos
    
    # Escalado de datos
    scaler = StandardScaler()
    scaled_data = scaler.fit_transform(data_cleaned)
    scaled_data_df = pd.DataFrame(scaled_data, columns=data_cleaned.columns)
    
    return scaled_data_df
