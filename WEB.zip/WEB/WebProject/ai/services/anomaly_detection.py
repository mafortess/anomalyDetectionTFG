# ai/services/anomaly_detection.py

from ai.models.anomaly_detection import train_isolation_forest
from ai.utils.data_preprocessing import prepare_data
import pandas as pd

def detect_anomalies(data):
    """
    Detecta anomalías en un conjunto de datos dado.

    :param data: DataFrame con los datos para la detección de anomalías.
    :return: DataFrame con la columna adicional 'anomaly' indicando si es una anomalía.
    """
    # Preparar datos
    prepared_data = prepare_data(data)

    # Entrenar modelo
    model = train_isolation_forest(prepared_data)

    # Predecir anomalías (-1 indica anomalía, 1 indica normal)
    predictions = model.predict(prepared_data)
    data['anomaly'] = predictions

    return data

# Ejemplo de uso:
# df = pd.read_csv('tu_archivo.csv')
# resultados_anomalías = detect_anomalies(df)
# print(resultados_anomalías.head())
