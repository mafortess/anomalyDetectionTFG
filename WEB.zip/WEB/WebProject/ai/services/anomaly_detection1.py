import requests
import numpy as np
from sklearn.ensemble import IsolationForest

# Función para consultar datos de Prometheus
def get_prometheus_data(query):
    url = 'http://localhost:9090/api/v1/query'
    response = requests.get(url, params={'query': query})
    result = response.json()['data']['result']
    timestamps = [float(point[0]) for point in result[0]['values']]
    values = [float(point[1]) for point in result[0]['values']]
    return np.array(timestamps), np.array(values)

# Consulta a Prometheus
query = '(node_cpu_seconds_total{mode="idle", job="kali"})'
timestamps, values = get_prometheus_data(query)

# Preprocesamiento
data = values.reshape(-1, 1)

# Entrenamiento del modelo de aislamiento forestal
model = IsolationForest(contamination=0.01)
model.fit(data)

# Detección de anomalías
anomalies = model.predict(data)
anomalies_index = np.where(anomalies == -1)[0]

# Imprimir los índices de las anomalías
print("Anomalías detectadas en los índices:", anomalies_index)
