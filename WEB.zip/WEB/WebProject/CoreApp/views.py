from django.shortcuts import render

# Create your views here.

def index(request):
    context = {
        'host_ip': '192.168.1.101'  # Aquí puedes pasar la IP que necesites
    }
    return render(request, 'CoreApp/index.html', context)

def about(request):
    return render(request, 'CoreApp/about.html', {})

def help(request):
    return render(request, 'CoreApp/help.html', {})

def contact(request):
    return render(request, 'CoreApp/contact.html', {})


#from django.http import HttpResponse

#def index(request):
#    return HttpResponse("MENHello, world. You're at the monitor index.")