from django.shortcuts import render
from django.http import JsonResponse
from prometheus_api_client import PrometheusConnect, MetricSnapshotDataFrame
import pandas as pd
from river.preprocessing import StandardScaler
from river.ensemble import IsolationForest
import pickle

# Inicializar el modelo y el escalador globalmente
scaler = StandardScaler()
model = IsolationForest(n_estimators=10, seed=42)
prom = PrometheusConnect(url="http://localhost:9090", disable_ssl=True)

# Función para recolectar datos de Prometheus
def get_prometheus_data(metric_name):
    metric_data = prom.get_current_metric_value(metric_name=metric_name)
    df = MetricSnapshotDataFrame(metric_data)
    return df['value'].astype(float).values.reshape(-1, 1)

# Vista para recolectar datos en tiempo real
def collect_data():
    cpu_usage = get_prometheus_data('node_cpu_seconds_total')
    memory_usage = get_prometheus_data('node_memory_MemAvailable_bytes')
    disk_io = get_prometheus_data('node_disk_io_time_seconds_total')
    network_io = get_prometheus_data('node_network_receive_bytes_total')
    
    data = pd.DataFrame({
        'cpu_usage': cpu_usage.flatten(),
        'memory_usage': memory_usage.flatten(),
        'disk_io': disk_io.flatten(),
        'network_io': network_io.flatten()
    })
    
    return data

# Vista para recolectar y devolver datos
def collect_data_view(request):
    data = collect_data()
    return JsonResponse(data.to_dict())

# Vista para entrenar el modelo
def train_model(request):
    df = pd.read_csv('historical_metrics.csv')
    features = ['cpu_usage', 'memory_usage', 'disk_io', 'network_io']
    data = df[features]
    
    for index, row in data.iterrows():
        x = dict(row)
        x = scaler.learn_one(x).transform_one(x)
        model.learn_one(x)
    
    with open('isolation_forest_model.pkl', 'wb') as f:
        pickle.dump((scaler, model), f)
    
    return JsonResponse({'status': 'Model trained successfully'})

# Vista para evaluar el modelo
def evaluate_model(request):
    df = pd.read_csv('new_metrics_data.csv')
    features = ['cpu_usage', 'memory_usage', 'disk_io', 'network_io']
    data = df[features]
    
    with open('isolation_forest_model.pkl', 'rb') as f:
        scaler, model = pickle.load(f)
    
    anomalies = []
    for index, row in data.iterrows():
        x = dict(row)
        x = scaler.transform_one(x)
        if model.score_one(x) > model.threshold:
            anomalies.append(row.to_dict())
    
    return JsonResponse({'anomalies': anomalies})

# Vista para detectar anomalías en tiempo real
def detect_anomalies(request):
    data = collect_data()
    
    with open('isolation_forest_model.pkl', 'rb') as f:
        scaler, model = pickle.load(f)
    
    anomalies = []
    for index, row in data.iterrows():
        x = dict(row)
        x = scaler.transform_one(x)
        if model.score_one(x) > model.threshold:
            anomalies.append(row.to_dict())
    
    return JsonResponse({'anomalies': anomalies})

# Vistas adicionales para servir las plantillas
def train_model_view(request):
    return render(request, 'train_model.html')

def detect_anomalies_view(request):
    return render(request, 'detect_anomalies.html')
