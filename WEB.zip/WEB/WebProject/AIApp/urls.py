from django.urls import path
from . import views
from .views import collect_data_view, train_model, evaluate_model, detect_anomalies

urlpatterns = [
    path("", views.main, name="AIMain"),
    path('collect-data/', collect_data_view, name='collect_data'),
    path('train-model/', train_model, name='train_model'),
    path('evaluate-model/', evaluate_model, name='evaluate_model'),
    path('detect-anomalies/', detect_anomalies, name='detect_anomalies'),   ]