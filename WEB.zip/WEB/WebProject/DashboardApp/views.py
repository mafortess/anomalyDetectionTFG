from django.shortcuts import render

# Create your views here.

#Plantilla para las subpáginas con React
def tempdash(request):
    return render(request, 'DashboardApp/tempdashboard.html', {})

#Vistas sin usar React
def practdash(request):
    return render(request, 'DashboardApp/practdashboard.html', {})

def hostdash(request):
    return render(request, 'DashboardApp/HostDashboard.html', {})

def containerdash(request):
    return render(request, 'DashboardApp/ContainerDashboard.html', {})

def energytdash(request):
    return render(request, 'DashboardApp/EnergyTDashboard.html', {})

def energypdash(request):
    return render(request, 'DashboardApp/EnergyPDashboard.html', {})

def aihostdash(request):
    return render(request, 'DashboardApp/AiHostDashboard.html', {})

def aicontainerdash(request):
    return render(request, 'DashboardApp/AiContainerDashboard.html', {})

def batchdash(request):
    return render(request, 'DashboardApp/BatchDashboard.html', {})

def k8sdash(request):
    return render(request, 'DashboardApp/K8sDashboard.html', {})  
