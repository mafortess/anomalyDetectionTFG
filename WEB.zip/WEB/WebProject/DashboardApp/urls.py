from django.urls import path, re_path
from django.views.generic import TemplateView
from . import views

urlpatterns = [
    path("practdash", views.practdash, name="practdashboard"),
    #Rutas Django
    path("host", views.hostdash, name="HostDashboard"),
    path('container', views.containerdash, name="ContainerDashboard"),
    path("energyt", views.energytdash, name="EnergyTDashboard"),
    path("aihost", views.aihostdash, name="AiHostDashboard"),   
    path("aicontainer", views.aicontainerdash, name="AiContainerDashboard"),
    path('k8s', views.k8sdash, name="K8sDashboard"),
    path("energyp", views.energypdash, name="EnergyPDashboard"),
    path("batchdash", views.batchdash, name="BatchDashboard"),   

    #re_path(r'^.*$', TemplateView.as_view(template_name="DashboardApp/tempdashboard.html"), name='tempdashboard'),
    #re_path('', views.tempdash, name='dashboard'),  # Captura todas las rutas de dashboard
    #path('', views.tempdash, name='tempdashboard'),
    #path("tempdash", views.tempdash, name="tempdashboard"),x
]