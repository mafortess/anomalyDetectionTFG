# urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('scan_network/', views.scan_network, name='scan_network'),
    path('tshark/', views.view_tshark_captures, name='view_tshark_captures'),
    path('list_captures/', views.list_captures, name='list_captures'),
    path('download_capture/', views.download_capture, name='download_capture'),

]
