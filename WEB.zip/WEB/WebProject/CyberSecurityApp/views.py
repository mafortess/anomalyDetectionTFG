from django.shortcuts import render
from django.http import JsonResponse
import subprocess
import nmap
import requests
from django.http import HttpResponse, HttpResponseBadRequest
import os

CLOUDSHARK_API_KEY = 'c19b717398e4cbb2bc3b5d1fecd99770'
CAPTURE_DIRECTORY = '/tmp/captures/'


#def scan_network(request):
 #   if request.method == "POST":
 #       target = request.POST.get("target")
  #      if target:
 #           try:
                # Crear una instancia del escáner nmap
      #          nm = nmap.PortScanner()
                # Ejecutar el escaneo
                # Replace with the appropriate IP address or hostname
                #nm.scan(target, '22-443')  # Scan from port 22 to 443
                #scan_data = nm.all_hosts()
                #return render(request, {'scan_data': scan_data})
                #print(scan_data)

 #               result = nm.scan(hosts=target, arguments='-sV')
                 # Formatear los resultados
           #     output = ''
          #      for host in scan_data['scan']:
         #           output += f"Host: {host}\n"
        #            for proto in scan_data['scan'][host]:
               #         output += f"Protocol: {proto}\n"
       #                 ports = scan_data['scan'][host][proto]
      #                  for port in ports:
     #                       output += f"Port: {port}, State: {ports[port]['state']}, Service: {ports[port]['name']}\n"

    #            print("RESPUESTA ",nm.csv())
   #             return JsonResponse({"output": result})
  #          except Exception as e:
 #               return JsonResponse({"error": str(e)}, status=500)
#    return render(request, 'CyberSecurityApp/scan_network.html')

import subprocess
from django.http import JsonResponse

def scan_network(request):
    host_ip = request.GET.get('ip')
    if not host_ip:
        return JsonResponse({'error': 'IP no proporcionada'}, status=400)

    try:
        if request.method == "GET":
            result = subprocess.run(['sudo', 'nmap', '-sS', host_ip, '-p-', '-oG', '-'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            output = result.stdout.decode('utf-8')
            error = result.stderr.decode('utf-8')

            # Imprimir la salida y el error para depuración
            print("Nmap output:", output)
            print("Nmap error:", error)

            if result.returncode != 0:
                return JsonResponse({'error': error}, status=500)

            ports_info = parse_nmap_output(output)
            print("Parsed ports info:", ports_info)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

    return JsonResponse({'output': ports_info})

def parse_nmap_output(output):
    ports_info = []
    lines = output.split('\n')
    for line in lines:
        if 'Ports:' in line:
            ports_section = line.split('Ports: ')[1]
            ports = ports_section.split(',')
            for port in ports:
                port_details = port.strip().split('/')
                port_info = {
                    'port': port_details[0],
                    'state': port_details[1],
                    'service': port_details[2]
                }
                ports_info.append(port_info)
    return ports_info

def view_tshark_captures(request):
    capture_id = request.GET.get('id')
    
    if not capture_id:
        return HttpResponseBadRequest("No capture ID specified.")
    
    # Construir la URL de descarga usando el ID de captura
    base_url = 'https://www.cloudshark.org/api/v1/'
    api_key = 'c19b717398e4cbb2bc3b5d1fecd99770'
    capture_url = f"{base_url}{api_key}/download/{capture_id}"
    
    # Imprimir la URL para depuración
    print(f"Constructed capture URL: {capture_url}")
    
    # Descargar el archivo de captura desde CloudShark
    try:
        response = requests.get(capture_url)
        response.raise_for_status()
        capture_file = '/tmp/capture.pcap'
        with open(capture_file, 'wb') as f:
            f.write(response.content)
    except requests.RequestException as e:
        return HttpResponseBadRequest(f"Error downloading capture file: {e}")
    
    # Verificar si el archivo existe y tiene contenido
    if not os.path.exists(capture_file) or os.path.getsize(capture_file) == 0:
        return HttpResponseBadRequest("Downloaded file is empty or does not exist.")
    
    # Leer el archivo y prepararlo para su descarga
    try:
        with open(capture_file, 'rb') as f:
            file_data = f.read()
    except Exception as e:
        return HttpResponseBadRequest(f"Error reading capture file: {e}")

    # Devolver el archivo como una respuesta de descarga
    response = HttpResponse(file_data, content_type='application/vnd.tcpdump.pcap')
    response['Content-Disposition'] = f'attachment; filename="capture_{capture_id}.pcap"'
    return response

def check_prometheus_status(request):
    host = request.GET.get('host')
    prometheus_url = 'http://your-prometheus-server/api/v1/targets'

    if not host:
        return JsonResponse({'error': 'No host specified'}, status=400)

    # Verificar si el host está siendo scrapeado por Prometheus
    try:
        response = requests.get(prometheus_url)
        response.raise_for_status()
        data = response.json()
        being_scraped = any(target['scrapePool'] == 'your_scrape_pool' and target['discoveredLabels']['__address__'] == host for target in data['data']['activeTargets'])
    except Exception as e:
        return JsonResponse({'error': f'Error checking Prometheus status: {e}'}, status=500)

    return JsonResponse({'being_scraped': being_scraped})

def list_captures(request):
    host = request.GET.get('host')
    capture_directory = '/tmp/captures/'

    if not host:
        return JsonResponse({'error': 'No host specified'}, status=400)

    # Listar todas las capturas disponibles para el host especificado
    captures = [f for f in os.listdir(capture_directory) if host in f]
    if not captures:
        return JsonResponse({'error': 'No captures found for this host'}, status=404)

    captures = sorted(captures, key=lambda x: os.path.getctime(os.path.join(capture_directory, x)), reverse=True)
    return JsonResponse({'captures': captures})

def download_capture(request):
    filename = request.GET.get('filename')
    capture_directory = '/tmp/captures/'
    capture_path = os.path.join(capture_directory, filename)

    if not filename or not os.path.exists(capture_path):
        return JsonResponse({'error': 'Capture file not found'}, status=404)

    # Leer el archivo y devolver la respuesta
    try:
        with open(capture_path, 'rb') as f:
            file_data = f.read()
    except Exception as e:
        return JsonResponse({'error': f"Error reading capture file: {e}"}, status=500)

    response = HttpResponse(file_data, content_type='application/vnd.tcpdump.pcap')
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    return response

#Para mostrarlo en un div:    
"""def view_tshark_captures(request):
    capture_id = request.GET.get('id')
    
    if not capture_id:
        return HttpResponseBadRequest("No capture ID specified.")
    
    # Construir la URL de descarga usando el ID de captura
    base_url = 'https://www.cloudshark.org/api/v1/'
    api_key = 'c19b717398e4cbb2bc3b5d1fecd99770'
    capture_url = f"{base_url}{api_key}/download/{capture_id}"
    
    # Imprimir la URL para depuración
    print(f"Constructed capture URL: {capture_url}")
    
    # Descargar el archivo de captura desde CloudShark
    try:
        response = requests.get(capture_url)
        response.raise_for_status()
    except requests.RequestException as e:
        return HttpResponseBadRequest(f"Error downloading capture file: {e}")
    
    # Guardar el archivo de captura temporalmente
    capture_file = '/tmp/capture.pcap'
    with open(capture_file, 'wb') as f:
        f.write(response.content)
    
    # Ejecutar Tshark en el archivo de captura descargado
    try:
        result = subprocess.run(['tshark', '-r', capture_file], capture_output=True, text=True, check=True)
    except subprocess.CalledProcessError as e:
        return JsonResponse({'error': f"Error running tshark: {e}\nOutput: {e.output}\nError: {e.stderr}"}, status=400)

    # Devolver la salida de Tshark como JSON
    return JsonResponse({'output': result.stdout})"""

#def scan_network(request):
 #   if request.method == "POST":
  #      target = request.POST.get("target")
   #     if target:
    #        # Ejecutar el comando nmap
    #        result = subprocess.run(["nmap", "-sV", target], capture_output=True, text=True)
     #       return JsonResponse({"output": result.stdout})
   # return render(request, "CyberSecurityApp/scan_network.html")