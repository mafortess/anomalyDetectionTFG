from django.apps import AppConfig


class CybersecurityappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'CyberSecurityApp'
