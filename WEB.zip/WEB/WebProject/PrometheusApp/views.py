from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.http import require_GET
import requests

PROMETHEUS_URL = 'http://192.168.1.138:9090/api/v1/query'

def query_prometheus(query):
    response = requests.get(PROMETHEUS_URL, params={'query': query})
    
    if response.status_code == 200:
        data = response.json()
        if 'data' in data and 'result' in data['data'] and len(data['data']['result']) > 0:
            return data['data']['result'][0]['value'][1]
        else:
            return None
    else:
        return None

@require_GET
def get_metrics(request):
    host = request.GET.get('host')
    if not host:
        return JsonResponse({'error': 'Invalid host'}, status=400)

    if host == 'windowshost':
        metrics = {
            'cpu': f'100 - (avg by (instance) (rate(windows_cpu_time_total{{mode="idle"}}[5m])) * 100)',
            'ram': f'(windows_cs_physical_memory_bytes - windows_os_physical_memory_free_bytes) / windows_cs_physical_memory_bytes * 100',
            'network': f'rate(windows_net_bytes_received_total[5m])',
            'disk': f'(windows_logical_disk_size_bytes - windows_logical_disk_free_bytes) / windows_logical_disk_size_bytes * 100'
        }

    else: 
        metrics = {
            'cpu': f'100 - (avg by (instance) (rate(node_cpu_seconds_total{{mode="idle", job="{host}"}}[5m])) * 100)',
            'ram': f'node_memory_MemAvailable_bytes{{job="{host}"}} / node_memory_MemTotal_bytes{{job="{host}"}} * 100',
            'network': f'rate(node_network_receive_bytes_total{{job="{host}"}}[5m])',
            'disk': f'(node_filesystem_size_bytes{{job="{host}"}} - node_filesystem_avail_bytes{{job="{host}"}}) / node_filesystem_size_bytes{{job="{host}"}} * 100'
        }

    results = {}
    for key, query in metrics.items():
        results[key] = query_prometheus(query)

    print("Metrics fetched:", results)  # Mensaje de depuración
    return JsonResponse(results)

PROMETHEUS_ALERTS_URL = 'http://192.168.1.138:9090/api/v1/alerts'

@require_GET
def get_alerts(request):
    host = request.GET.get('host')
    if not host:
    #if host not in ['kali', 'debianhost', 'windowshost']:
        return JsonResponse({'error': 'Invalid host'}, status=400)

    response = requests.get(PROMETHEUS_ALERTS_URL)
    alerts = []
    host_alerts = []
    if response.status_code == 200:
        alerts = response.json().get('data', {}).get('alerts', [])
        host_alerts = [alert for alert in alerts if host in alert['labels'].get('instance', '')]
        #print("Alerts fetched:", alerts)
        #print("Alerts fetched:", host_alerts)
        return JsonResponse({'alerts': alerts})
    else:
        return JsonResponse({'error': 'Failed to fetch alerts'}, status=500)


PROMETHEUS_RULES_URL = 'http://192.168.1.138:9090/api/v1/rules'

@require_GET
def get_rules(request):
    host = request.GET.get('host')
    if not host:
        return JsonResponse({'error': 'Invalid host'}, status=400)

    response = requests.get(PROMETHEUS_RULES_URL)
    if response.status_code == 200:
        rules = response.json().get('data', {}).get('groups', [])
        #print("Rules fetched:",rules_data)
        #rules_titles = []
        #for group in rules_data:
         #   for rule in group.get('rules', []):
          #      if 'alert' in rule:
           #         if 'labels' in rule and 'instance' in rule['labels'] and rule['labels']['instance'] == host:
            #            rules_titles.append(rule['alert'])
        #print("Rules fetched:", rules)
        return JsonResponse({'rules': rules})
    else:
        return JsonResponse({'error': 'Failed to fetch rules'}, status=500)