from django.urls import path, re_path
from django.views.generic import TemplateView
from . import views
from .views import get_metrics, get_alerts, get_rules

urlpatterns = [
  #USO API PROMETHEUS
    path("get_metrics", get_metrics, name='get_metrics'),
    path('get_alerts', get_alerts, name='get_alerts'),
    path('get_rules', get_rules, name='get_rules'),
]